from classe import Cadastro

guilherme = Cadastro('Guilherme', 'Ribeiro', 18, 'Masculino', 'Rua Reinaldo Sbardeloto')

print(vars(guilherme))