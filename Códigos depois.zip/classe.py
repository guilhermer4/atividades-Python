class Cadastro:
    def __init__(self, nome, sobrenome, idade, genero, endereco):
        print("Iniciando um cadastro")
        self.nome = nome
        self.sobrenome = sobrenome
        self.idade = idade
        self.genero = genero
        self.endereco = endereco

    def certifique_seu_nome(self, identificacao):
        print('nome')
        if resposta == "y":
            print("Nome correto")
        else:
            print("Nome inválido")

    def certifique_seu_sobrenome(self, identificacao):
        print('sobrenome')
        if resposta == "y":
            print("Sobrenome correto")
        else:
            print("Sobrenome inválido")

    def certifique_sua_idade(self, identificacao):
        print('idade')
        if resposta == "18":
            print("Idade válida")
        else:
            print("Negado, restrição de idade")

    def certifique_seu_genero(self, identificacao):
        print('genero')
        if resposta == "1":
            print("Masculino")
        if resposta == "2":
            print("Feminino")

    def certifique_seu_endereco(self, identificacao):
        print('endereco')
        if resposta == "y":
            print("Endereço válido")
        else:
            print("Endereço inválido")

    def mostrar_dados(self):
        print('nome', self.nome, 'sobrenome', self.sobrenome, 'idade', self.idade, 'genero', self.genero, 'endereco', self.endereco)






